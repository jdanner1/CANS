CREATE VIEW user_summary_by_file_io AS
  SELECT
    if(isnull(`performance_schema`.`events_waits_summary_by_user_by_event_name`.`USER`), 'background',
       `performance_schema`.`events_waits_summary_by_user_by_event_name`.`USER`)                                 AS `user`,
    sum(
        `performance_schema`.`events_waits_summary_by_user_by_event_name`.`COUNT_STAR`)                          AS `ios`,
    `sys`.`format_time`(sum(
                            `performance_schema`.`events_waits_summary_by_user_by_event_name`.`SUM_TIMER_WAIT`)) AS `io_latency`
  FROM `performance_schema`.`events_waits_summary_by_user_by_event_name`
  WHERE (`performance_schema`.`events_waits_summary_by_user_by_event_name`.`EVENT_NAME` LIKE 'wait/io/file/%')
  GROUP BY if(isnull(`performance_schema`.`events_waits_summary_by_user_by_event_name`.`USER`), 'background',
              `performance_schema`.`events_waits_summary_by_user_by_event_name`.`USER`)
  ORDER BY sum(`performance_schema`.`events_waits_summary_by_user_by_event_name`.`SUM_TIMER_WAIT`) DESC;
